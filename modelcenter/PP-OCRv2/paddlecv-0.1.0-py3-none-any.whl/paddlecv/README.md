# PaddleModelPipeline


# Whl package

* Install

```bash
python setup.py bdist_wheel
pip install dist/paddlecv-0.1.0-py3-none-any.whl
```

* Usage

```py
from paddlecv import PaddleCV
ppcv = PaddleCV(task_name="PP-OCRv3")
res = ppcv("../demo/00056221.jpg")
```
